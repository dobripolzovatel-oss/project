/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.unused.packageinfo;

import javax.annotation.ParametersAreNonnullByDefault;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.annotation.ClientFieldsAreNonnullByDefault;
import net.minecraft.util.annotation.ClientMethodsReturnNonnullByDefault;

@ParametersAreNonnullByDefault
@ClientMethodsReturnNonnullByDefault
@ClientFieldsAreNonnullByDefault
@Environment(value=EnvType.CLIENT)
interface PackageInfo6185 {
}

