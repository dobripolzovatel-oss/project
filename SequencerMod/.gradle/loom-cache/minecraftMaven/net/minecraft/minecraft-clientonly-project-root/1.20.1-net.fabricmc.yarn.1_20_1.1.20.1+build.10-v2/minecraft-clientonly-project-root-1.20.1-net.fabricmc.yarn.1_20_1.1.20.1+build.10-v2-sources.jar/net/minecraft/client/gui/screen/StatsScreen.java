/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.gui.screen;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.StatsListener;
import net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.EntityType;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stat;
import net.minecraft.stat.StatHandler;
import net.minecraft.stat.StatType;
import net.minecraft.stat.Stats;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.jetbrains.annotations.Nullable;

@Environment(value=EnvType.CLIENT)
public class StatsScreen
extends Screen
implements StatsListener {
    private static final Text DOWNLOADING_STATS_TEXT = Text.translatable((String)"multiplayer.downloadingStats");
    private static final Identifier STATS_ICONS_TEXTURE = new Identifier("textures/gui/container/stats_icons.png");
    protected final Screen parent;
    private GeneralStatsListWidget generalStats;
    ItemStatsListWidget itemStats;
    private EntityStatsListWidget mobStats;
    final StatHandler statHandler;
    @Nullable
    private AlwaysSelectedEntryListWidget<?> selectedList;
    private boolean downloadingStats = true;
    private static final int field_32281 = 128;
    private static final int field_32282 = 18;
    private static final int field_32283 = 20;
    private static final int field_32284 = 1;
    private static final int field_32285 = 1;
    private static final int field_32274 = 2;
    private static final int field_32275 = 2;
    private static final int field_32276 = 40;
    private static final int field_32277 = 5;
    private static final int field_32278 = 0;
    private static final int field_32279 = -1;
    private static final int field_32280 = 1;

    public StatsScreen(Screen parent, StatHandler statHandler) {
        super((Text)Text.translatable((String)"gui.stats"));
        this.parent = parent;
        this.statHandler = statHandler;
    }

    @Override
    protected void init() {
        this.downloadingStats = true;
        this.client.getNetworkHandler().sendPacket((Packet<?>)new ClientStatusC2SPacket(ClientStatusC2SPacket.Mode.REQUEST_STATS));
    }

    public void createLists() {
        this.generalStats = new GeneralStatsListWidget(this.client);
        this.itemStats = new ItemStatsListWidget(this.client);
        this.mobStats = new EntityStatsListWidget(this.client);
    }

    public void createButtons() {
        this.addDrawableChild(ButtonWidget.builder((Text)Text.translatable((String)"stat.generalButton"), button -> this.selectStatList(this.generalStats)).dimensions(this.width / 2 - 120, this.height - 52, 80, 20).build());
        ButtonWidget buttonWidget = this.addDrawableChild(ButtonWidget.builder((Text)Text.translatable((String)"stat.itemsButton"), button -> this.selectStatList(this.itemStats)).dimensions(this.width / 2 - 40, this.height - 52, 80, 20).build());
        ButtonWidget buttonWidget2 = this.addDrawableChild(ButtonWidget.builder((Text)Text.translatable((String)"stat.mobsButton"), button -> this.selectStatList(this.mobStats)).dimensions(this.width / 2 + 40, this.height - 52, 80, 20).build());
        this.addDrawableChild(ButtonWidget.builder(ScreenTexts.DONE, button -> this.client.setScreen(this.parent)).dimensions(this.width / 2 - 100, this.height - 28, 200, 20).build());
        if (this.itemStats.children().isEmpty()) {
            buttonWidget.active = false;
        }
        if (this.mobStats.children().isEmpty()) {
            buttonWidget2.active = false;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        if (this.downloadingStats) {
            this.renderBackground(context);
            context.drawCenteredTextWithShadow(this.textRenderer, DOWNLOADING_STATS_TEXT, this.width / 2, this.height / 2, 0xFFFFFF);
            context.drawCenteredTextWithShadow(this.textRenderer, PROGRESS_BAR_STAGES[(int)(Util.getMeasuringTimeMs() / 150L % (long)PROGRESS_BAR_STAGES.length)], this.width / 2, this.height / 2 + this.textRenderer.fontHeight * 2, 0xFFFFFF);
        } else {
            this.getSelectedStatList().render(context, mouseX, mouseY, delta);
            context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 20, 0xFFFFFF);
            super.render(context, mouseX, mouseY, delta);
        }
    }

    @Override
    public void onStatsReady() {
        if (this.downloadingStats) {
            this.createLists();
            this.createButtons();
            this.selectStatList(this.generalStats);
            this.downloadingStats = false;
        }
    }

    @Override
    public boolean shouldPause() {
        return !this.downloadingStats;
    }

    @Nullable
    public AlwaysSelectedEntryListWidget<?> getSelectedStatList() {
        return this.selectedList;
    }

    public void selectStatList(@Nullable AlwaysSelectedEntryListWidget<?> list) {
        if (this.selectedList != null) {
            this.remove(this.selectedList);
        }
        if (list != null) {
            this.addSelectableChild(list);
            this.selectedList = list;
        }
    }

    static String getStatTranslationKey(Stat<Identifier> stat) {
        return "stat." + ((Identifier)stat.getValue()).toString().replace(':', '.');
    }

    int getColumnX(int index) {
        return 115 + 40 * index;
    }

    void renderStatItem(DrawContext context, int x, int y, Item item) {
        this.renderIcon(context, x + 1, y + 1, 0, 0);
        context.drawItemWithoutEntity(item.getDefaultStack(), x + 2, y + 2);
    }

    void renderIcon(DrawContext context, int x, int y, int u, int v) {
        context.drawTexture(STATS_ICONS_TEXTURE, x, y, 0, u, v, 18, 18, 128, 128);
    }

    @Environment(value=EnvType.CLIENT)
    class GeneralStatsListWidget
    extends AlwaysSelectedEntryListWidget<Entry> {
        public GeneralStatsListWidget(MinecraftClient client) {
            super(client, StatsScreen.this.width, StatsScreen.this.height, 32, StatsScreen.this.height - 64, 10);
            ObjectArrayList<Stat> objectArrayList = new ObjectArrayList<Stat>(Stats.CUSTOM.iterator());
            objectArrayList.sort(Comparator.comparing(stat -> I18n.translate(StatsScreen.getStatTranslationKey((Stat<Identifier>)stat), new Object[0])));
            for (Stat stat2 : objectArrayList) {
                this.addEntry(new Entry((Stat<Identifier>)stat2));
            }
        }

        @Override
        protected void renderBackground(DrawContext context) {
            StatsScreen.this.renderBackground(context);
        }

        @Environment(value=EnvType.CLIENT)
        class Entry
        extends AlwaysSelectedEntryListWidget.Entry<Entry> {
            private final Stat<Identifier> stat;
            private final Text displayName;

            Entry(Stat<Identifier> stat) {
                this.stat = stat;
                this.displayName = Text.translatable((String)StatsScreen.getStatTranslationKey(stat));
            }

            private String getFormatted() {
                return this.stat.format(StatsScreen.this.statHandler.getStat(this.stat));
            }

            @Override
            public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
                context.drawTextWithShadow(StatsScreen.this.textRenderer, this.displayName, x + 2, y + 1, index % 2 == 0 ? 0xFFFFFF : 0x909090);
                String string = this.getFormatted();
                context.drawTextWithShadow(StatsScreen.this.textRenderer, string, x + 2 + 213 - StatsScreen.this.textRenderer.getWidth(string), y + 1, index % 2 == 0 ? 0xFFFFFF : 0x909090);
            }

            @Override
            public Text getNarration() {
                return Text.translatable((String)"narrator.select", (Object[])new Object[]{Text.empty().append(this.displayName).append(ScreenTexts.SPACE).append(this.getFormatted())});
            }
        }
    }

    @Environment(value=EnvType.CLIENT)
    class ItemStatsListWidget
    extends AlwaysSelectedEntryListWidget<Entry> {
        protected final List<StatType<Block>> blockStatTypes;
        protected final List<StatType<Item>> itemStatTypes;
        private final int[] HEADER_ICON_SPRITE_INDICES;
        protected int selectedHeaderColumn;
        protected final Comparator<Entry> comparator;
        @Nullable
        protected StatType<?> selectedStatType;
        protected int listOrder;

        public ItemStatsListWidget(MinecraftClient client) {
            boolean bl;
            super(client, StatsScreen.this.width, StatsScreen.this.height, 32, StatsScreen.this.height - 64, 20);
            this.HEADER_ICON_SPRITE_INDICES = new int[]{3, 4, 1, 2, 5, 6};
            this.selectedHeaderColumn = -1;
            this.comparator = new ItemComparator();
            this.blockStatTypes = Lists.newArrayList();
            this.blockStatTypes.add((StatType<Block>)Stats.MINED);
            this.itemStatTypes = Lists.newArrayList(Stats.BROKEN, Stats.CRAFTED, Stats.USED, Stats.PICKED_UP, Stats.DROPPED);
            this.setRenderHeader(true, 20);
            Set<Item> set = Sets.newIdentityHashSet();
            for (Item item : Registries.ITEM) {
                bl = false;
                for (StatType<Item> statType : this.itemStatTypes) {
                    if (!statType.hasStat((Object)item) || StatsScreen.this.statHandler.getStat(statType.getOrCreateStat((Object)item)) <= 0) continue;
                    bl = true;
                }
                if (!bl) continue;
                set.add(item);
            }
            for (Block block : Registries.BLOCK) {
                bl = false;
                for (StatType<Item> statType : this.blockStatTypes) {
                    if (!statType.hasStat((Object)block) || StatsScreen.this.statHandler.getStat(statType.getOrCreateStat((Object)block)) <= 0) continue;
                    bl = true;
                }
                if (!bl) continue;
                set.add(block.asItem());
            }
            set.remove(Items.AIR);
            for (Item item : set) {
                this.addEntry(new Entry(item));
            }
        }

        @Override
        protected void renderHeader(DrawContext context, int x, int y) {
            int j;
            int i;
            if (!this.client.mouse.wasLeftButtonClicked()) {
                this.selectedHeaderColumn = -1;
            }
            for (i = 0; i < this.HEADER_ICON_SPRITE_INDICES.length; ++i) {
                StatsScreen.this.renderIcon(context, x + StatsScreen.this.getColumnX(i) - 18, y + 1, 0, this.selectedHeaderColumn == i ? 0 : 18);
            }
            if (this.selectedStatType != null) {
                i = StatsScreen.this.getColumnX(this.getHeaderIndex(this.selectedStatType)) - 36;
                j = this.listOrder == 1 ? 2 : 1;
                StatsScreen.this.renderIcon(context, x + i, y + 1, 18 * j, 0);
            }
            for (i = 0; i < this.HEADER_ICON_SPRITE_INDICES.length; ++i) {
                j = this.selectedHeaderColumn == i ? 1 : 0;
                StatsScreen.this.renderIcon(context, x + StatsScreen.this.getColumnX(i) - 18 + j, y + 1 + j, 18 * this.HEADER_ICON_SPRITE_INDICES[i], 18);
            }
        }

        @Override
        public int getRowWidth() {
            return 375;
        }

        @Override
        protected int getScrollbarPositionX() {
            return this.width / 2 + 140;
        }

        @Override
        protected void renderBackground(DrawContext context) {
            StatsScreen.this.renderBackground(context);
        }

        @Override
        protected void clickedHeader(int x, int y) {
            this.selectedHeaderColumn = -1;
            for (int i = 0; i < this.HEADER_ICON_SPRITE_INDICES.length; ++i) {
                int j = x - StatsScreen.this.getColumnX(i);
                if (j < -36 || j > 0) continue;
                this.selectedHeaderColumn = i;
                break;
            }
            if (this.selectedHeaderColumn >= 0) {
                this.selectStatType(this.getStatType(this.selectedHeaderColumn));
                this.client.getSoundManager().play(PositionedSoundInstance.master((RegistryEntry<SoundEvent>)SoundEvents.UI_BUTTON_CLICK, 1.0f));
            }
        }

        private StatType<?> getStatType(int headerColumn) {
            return headerColumn < this.blockStatTypes.size() ? this.blockStatTypes.get(headerColumn) : this.itemStatTypes.get(headerColumn - this.blockStatTypes.size());
        }

        private int getHeaderIndex(StatType<?> statType) {
            int i = this.blockStatTypes.indexOf(statType);
            if (i >= 0) {
                return i;
            }
            int j = this.itemStatTypes.indexOf(statType);
            if (j >= 0) {
                return j + this.blockStatTypes.size();
            }
            return -1;
        }

        @Override
        protected void renderDecorations(DrawContext context, int mouseX, int mouseY) {
            if (mouseY < this.top || mouseY > this.bottom) {
                return;
            }
            Entry entry = (Entry)this.getHoveredEntry();
            int i = (this.width - this.getRowWidth()) / 2;
            if (entry != null) {
                if (mouseX < i + 40 || mouseX > i + 40 + 20) {
                    return;
                }
                Item item = entry.getItem();
                this.render(context, this.getText(item), mouseX, mouseY);
            } else {
                Text text = null;
                int j = mouseX - i;
                for (int k = 0; k < this.HEADER_ICON_SPRITE_INDICES.length; ++k) {
                    int l = StatsScreen.this.getColumnX(k);
                    if (j < l - 18 || j > l) continue;
                    text = this.getStatType(k).getName();
                    break;
                }
                this.render(context, text, mouseX, mouseY);
            }
        }

        protected void render(DrawContext drawContext, @Nullable Text text, int mouseX, int mouseY) {
            if (text == null) {
                return;
            }
            int i = mouseX + 12;
            int j = mouseY - 12;
            int k = StatsScreen.this.textRenderer.getWidth((StringVisitable)text);
            drawContext.fillGradient(i - 3, j - 3, i + k + 3, j + 8 + 3, -1073741824, -1073741824);
            drawContext.getMatrices().push();
            drawContext.getMatrices().translate(0.0f, 0.0f, 400.0f);
            drawContext.drawTextWithShadow(StatsScreen.this.textRenderer, text, i, j, -1);
            drawContext.getMatrices().pop();
        }

        protected Text getText(Item item) {
            return item.getName();
        }

        protected void selectStatType(StatType<?> statType) {
            if (statType != this.selectedStatType) {
                this.selectedStatType = statType;
                this.listOrder = -1;
            } else if (this.listOrder == -1) {
                this.listOrder = 1;
            } else {
                this.selectedStatType = null;
                this.listOrder = 0;
            }
            this.children().sort(this.comparator);
        }

        @Environment(value=EnvType.CLIENT)
        class ItemComparator
        implements Comparator<Entry> {
            ItemComparator() {
            }

            @Override
            public int compare(Entry entry, Entry entry2) {
                int j;
                int i;
                Item item = entry.getItem();
                Item item2 = entry2.getItem();
                if (ItemStatsListWidget.this.selectedStatType == null) {
                    i = 0;
                    j = 0;
                } else if (ItemStatsListWidget.this.blockStatTypes.contains(ItemStatsListWidget.this.selectedStatType)) {
                    StatType<?> statType = ItemStatsListWidget.this.selectedStatType;
                    i = item instanceof BlockItem ? StatsScreen.this.statHandler.getStat(statType, (Object)((BlockItem)item).getBlock()) : -1;
                    j = item2 instanceof BlockItem ? StatsScreen.this.statHandler.getStat(statType, (Object)((BlockItem)item2).getBlock()) : -1;
                } else {
                    StatType<?> statType = ItemStatsListWidget.this.selectedStatType;
                    i = StatsScreen.this.statHandler.getStat(statType, (Object)item);
                    j = StatsScreen.this.statHandler.getStat(statType, (Object)item2);
                }
                if (i == j) {
                    return ItemStatsListWidget.this.listOrder * Integer.compare(Item.getRawId((Item)item), Item.getRawId((Item)item2));
                }
                return ItemStatsListWidget.this.listOrder * Integer.compare(i, j);
            }

            @Override
            public /* synthetic */ int compare(Object a, Object b) {
                return this.compare((Entry)a, (Entry)b);
            }
        }

        @Environment(value=EnvType.CLIENT)
        class Entry
        extends AlwaysSelectedEntryListWidget.Entry<Entry> {
            private final Item item;

            Entry(Item item) {
                this.item = item;
            }

            public Item getItem() {
                return this.item;
            }

            @Override
            public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
                int i;
                StatsScreen.this.renderStatItem(context, x + 40, y, this.item);
                for (i = 0; i < StatsScreen.this.itemStats.blockStatTypes.size(); ++i) {
                    Stat stat = this.item instanceof BlockItem ? StatsScreen.this.itemStats.blockStatTypes.get(i).getOrCreateStat((Object)((BlockItem)this.item).getBlock()) : null;
                    this.render(context, stat, x + StatsScreen.this.getColumnX(i), y, index % 2 == 0);
                }
                for (i = 0; i < StatsScreen.this.itemStats.itemStatTypes.size(); ++i) {
                    this.render(context, StatsScreen.this.itemStats.itemStatTypes.get(i).getOrCreateStat((Object)this.item), x + StatsScreen.this.getColumnX(i + StatsScreen.this.itemStats.blockStatTypes.size()), y, index % 2 == 0);
                }
            }

            protected void render(DrawContext drawContext, @Nullable Stat<?> stat, int x, int y, boolean white) {
                String string = stat == null ? "-" : stat.format(StatsScreen.this.statHandler.getStat(stat));
                drawContext.drawTextWithShadow(StatsScreen.this.textRenderer, string, x - StatsScreen.this.textRenderer.getWidth(string), y + 5, white ? 0xFFFFFF : 0x909090);
            }

            @Override
            public Text getNarration() {
                return Text.translatable((String)"narrator.select", (Object[])new Object[]{this.item.getName()});
            }
        }
    }

    @Environment(value=EnvType.CLIENT)
    class EntityStatsListWidget
    extends AlwaysSelectedEntryListWidget<Entry> {
        public EntityStatsListWidget(MinecraftClient client) {
            super(client, StatsScreen.this.width, StatsScreen.this.height, 32, StatsScreen.this.height - 64, ((StatsScreen)StatsScreen.this).textRenderer.fontHeight * 4);
            for (EntityType entityType : Registries.ENTITY_TYPE) {
                if (StatsScreen.this.statHandler.getStat(Stats.KILLED.getOrCreateStat((Object)entityType)) <= 0 && StatsScreen.this.statHandler.getStat(Stats.KILLED_BY.getOrCreateStat((Object)entityType)) <= 0) continue;
                this.addEntry(new Entry(entityType));
            }
        }

        @Override
        protected void renderBackground(DrawContext context) {
            StatsScreen.this.renderBackground(context);
        }

        @Environment(value=EnvType.CLIENT)
        class Entry
        extends AlwaysSelectedEntryListWidget.Entry<Entry> {
            private final Text entityTypeName;
            private final Text killedText;
            private final boolean killedAny;
            private final Text killedByText;
            private final boolean killedByAny;

            public Entry(EntityType<?> entityType) {
                this.entityTypeName = entityType.getName();
                int i = StatsScreen.this.statHandler.getStat(Stats.KILLED.getOrCreateStat(entityType));
                if (i == 0) {
                    this.killedText = Text.translatable((String)"stat_type.minecraft.killed.none", (Object[])new Object[]{this.entityTypeName});
                    this.killedAny = false;
                } else {
                    this.killedText = Text.translatable((String)"stat_type.minecraft.killed", (Object[])new Object[]{i, this.entityTypeName});
                    this.killedAny = true;
                }
                int j = StatsScreen.this.statHandler.getStat(Stats.KILLED_BY.getOrCreateStat(entityType));
                if (j == 0) {
                    this.killedByText = Text.translatable((String)"stat_type.minecraft.killed_by.none", (Object[])new Object[]{this.entityTypeName});
                    this.killedByAny = false;
                } else {
                    this.killedByText = Text.translatable((String)"stat_type.minecraft.killed_by", (Object[])new Object[]{this.entityTypeName, j});
                    this.killedByAny = true;
                }
            }

            @Override
            public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean hovered, float tickDelta) {
                context.drawTextWithShadow(StatsScreen.this.textRenderer, this.entityTypeName, x + 2, y + 1, 0xFFFFFF);
                context.drawTextWithShadow(StatsScreen.this.textRenderer, this.killedText, x + 2 + 10, y + 1 + ((StatsScreen)StatsScreen.this).textRenderer.fontHeight, this.killedAny ? 0x909090 : 0x606060);
                context.drawTextWithShadow(StatsScreen.this.textRenderer, this.killedByText, x + 2 + 10, y + 1 + ((StatsScreen)StatsScreen.this).textRenderer.fontHeight * 2, this.killedByAny ? 0x909090 : 0x606060);
            }

            @Override
            public Text getNarration() {
                return Text.translatable((String)"narrator.select", (Object[])new Object[]{ScreenTexts.joinSentences((Text[])new Text[]{this.killedText, this.killedByText})});
            }
        }
    }
}

