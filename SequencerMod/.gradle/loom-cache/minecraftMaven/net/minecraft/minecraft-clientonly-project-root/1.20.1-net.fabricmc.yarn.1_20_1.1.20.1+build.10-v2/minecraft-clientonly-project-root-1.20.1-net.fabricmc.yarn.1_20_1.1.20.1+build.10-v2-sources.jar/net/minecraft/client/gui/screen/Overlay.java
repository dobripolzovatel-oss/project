/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.gui.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.Drawable;

@Environment(value=EnvType.CLIENT)
public abstract class Overlay
implements Drawable {
    public boolean pausesGame() {
        return true;
    }
}

