/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.gl;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gl.ShaderProgramSetupView;

@Environment(value=EnvType.CLIENT)
public interface EffectShaderProgram
extends ShaderProgramSetupView {
}

